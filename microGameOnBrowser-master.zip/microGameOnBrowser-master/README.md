# microGameOnBrowser
Build MicroGame on Browser with `HTML`, `CSS`, `Javascript`
 <br><br>
### [EBS SW](https://www.ebssw.kr/)에 탑재될 강의입니다    
<br><br>
아래엔 참고할 프로젝트들입니다.  
### `Turn On & Off Bulb`
https://www.youtube.com/watch?v=HwWIKbZ6BE4

### `Rock, Scissor, Paper`
https://www.youtube.com/watch?v=jaVNP3nIAv0

### `Tetris`
https://www.youtube.com/watch?v=iBNglVi9qww

### `Snake`
https://www.youtube.com/watch?v=xGmXxpIj6vs

### `Ping Pong`
https://www.youtube.com/watch?v=KoWqdEACyLI  
https://www.youtube.com/watch?v=ju09womACpQ

### `두더지 잡기`
https://www.youtube.com/watch?v=B4jGVBz7P9M

### `Flappy Bird`
https://www.youtube.com/watch?v=L07i4g-zhDA

### `Traffic Racing Game`
https://www.youtube.com/watch?v=oWaGkW1YDmk


### `MMORPG` on HTML5
https://www.youtube.com/watch?v=ZjuVCTZMnbg


## 위의 예시들을 기반으로 열심히 코딩중

# Comming Soon
